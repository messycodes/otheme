#!/system/bin/sh

MODPATH=${MODPATH}

echo "复制系统文件到模块目录"

mkdir -p "$MODPATH/system_ext/media"

cp -af /system_ext/media/* "$MODPATH/system_ext/media/"

echo "复制完成"