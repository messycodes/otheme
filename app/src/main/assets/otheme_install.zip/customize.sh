#!/system/bin/sh

ui_print "- 复制 system_ext/media"

mkdir -p "$MODPATH/system_ext/media"
mkdir -p "$MODPATH/system_ext/media/themeInner"

ui_print "本机 system_ext:"
ls /system_ext/media

cp -a /system_ext/media/. "$MODPATH/system_ext/media/"

ui_print "当前模块 system_ext"
ls "$MODPATH/system_ext/media"

ui_print "- 完成"