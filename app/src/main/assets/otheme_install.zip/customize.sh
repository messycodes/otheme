#!/system/bin/sh

ui_print "- 复制系统文件..."

mkdir -p "$MODPATH/system_ext/media"
mkdir -p "$MODPATH/system_ext/media/themeInner"
mkdir -p "$MODPATH/backup"

ui_print "本机 system_ext目标文件夹:"
ls /system_ext/media
ui_print "本机 my_stock目标文件夹:"
ls /my_stock/media/theme/

cp -a /system_ext/media/. "$MODPATH/system_ext/media/"
cp -a /my_stock/media/theme/. "$MODPATH/backup"

ui_print "复制成功"
ls "$MODPATH/system_ext/media"
ls "$MODPATH/backup"

ui_print "- 完成"