MODDIR=${0%/*}
mount --bind $MODDIR/system_ext/media/ /system_ext/media/
mount --bind $MODDIR/theme/ /my_stock/media/theme/