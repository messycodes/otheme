MODDIR=${0%/*}
mount --bind $MODDIR/system_ext/media/ /system_ext/media/