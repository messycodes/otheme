#!/system/bin/sh
MODDIR=${0%/*}
# 该脚本将在设备开机后作为延迟服务启动
bind $MODDIR/system_ext/media/ /system_ext/media/